#pragma once
#include "singletonBase.h"

class ScrollMgr : public singletonBase<ScrollMgr>
{
private:
	

public:
	ScrollMgr();
	~ScrollMgr();
};

