#include "stdafx.h"
#include "scene.h"


HRESULT scene::init()
{
	return S_OK;
}

void scene::release()
{
}

void scene::update()
{
}

void scene::render(HDC hdc)
{
}

scene::scene()
{
}


scene::~scene()
{
}
