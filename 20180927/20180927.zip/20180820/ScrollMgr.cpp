#include "stdafx.h"
#include "ScrollMgr.h"


ScrollMgr::ScrollMgr()
{
}


ScrollMgr::~ScrollMgr()
{
}
