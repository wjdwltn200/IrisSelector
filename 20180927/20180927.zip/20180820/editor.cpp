#include "stdafx.h"
#include "editor.h"
#include "button.h"
#include "image.h"

char szFileName_1[512];
int editor::m_nPreviewNum = 0;


static void SpaceFunc_left(void)
{
	if ((editor::m_nPreviewNum) > 0)
		editor::m_nPreviewNum -= 1;
}

static void SpaceFunc_right(void)
{
	if ((editor::m_nPreviewNum) < 3)
		editor::m_nPreviewNum += 1;
}

void editor::ButtonEvent(HWND hWnd, UINT iMessage, WPARAM wParam)
{
	switch (LOWORD(wParam))
	{
	case 32775: //Save
		MessageBox(hWnd, "Save Button Clicked", "Button", MB_OK);
		SaveEvent();
		break;
	case 32776: // Load
		MessageBox(hWnd, "Load Button Clicked", "Button", MB_OK);
		LoadEvent();
		break;
	case 32777: // Save and Start
		MessageBox(hWnd, "Eraser Button Clicked", "Button", MB_OK);
		break;
	case 32778: // Exit
		PostQuitMessage(0);
		break;

	case 32773: // Terrains 
		st_obj = isTerrain;
		break;
	case 32774: // Units
		st_obj = isUnit;
		break;

	case 32783: // ������üũ
		st_selSize = x800;
		m_bIsSelectSize = true;
		break;
	case 32784:
		st_selSize = x1600;
		m_bIsSelectSize = true;
		break;
	case 32785:
		st_selSize = x2000;
		m_bIsSelectSize = true;
		break;
	case 32786:
		st_selSize = x2400;
		m_bIsSelectSize = true;
		break;

	case 32772:
		// ���� �ѱ�
		break;
	}

}







HRESULT editor::init()
{
	st_selSize = x2400;
	st_selTile = tileset1;
	m_bIsSelectSize = false; // �޴����� ������üũ�� �ʱ�ȭ�ǰ� ������ �ٽ������ȴ�.
	g_saveData.gTileMaxCountX = 60;
	g_saveData.gTileMaxCountY = 60;




	return S_OK;
}

void editor::release()
{
}

void editor::update()
{
}

void editor::SizeUpdate()
{
	if (m_bIsSelectSize == true)
	{





	}
}

void editor::render(HDC hdc)
{
}

void editor::SaveEvent()
{
}

void editor::LoadEvent()
{
}
















editor::editor()
{
}


editor::~editor()
{
}
