//#pragma once
#include "scene.h"
#include "stdafx.h"
//#define TILE_SIZE 32
//
//
//#define SAMPLE_TILE_X 20
//#define SAMPLE_TILE_Y 9
//
//
//
//
//
//
//class tileMap : public scene
//{
//private:
//	HWND	m_hBtnSave;
//	HWND	m_hBtnLoad;
//	HWND	m_hBtnSelectTerrain;
//	HWND	m_hBtnSelectObject;
//	HWND	m_hBtnEraser;
//
//	image*	m_pTileSet;
//	image*	m_pObjSet;
//	image*	m_pObj1Set;
//
//	tagTile	 m_pTiles[TILE_X * TILE_Y]; //������ �׸��� �����ϴ� ����
//	tagSampleTile	m_pSampleTiles[SAMPLE_TILE_X * SAMPLE_TILE_Y]; 
//	RECT	m_rcSelectedTile; //���� ���õ� Ÿ������ ������ ���� 
//
//	POINT m_Mouse;
//
//	bool m_bObjPrint;
//
//public:
//	HRESULT init();
//	void release();
//	void update();
//	void render(HDC hdc);
//
//	void objectPrint();
//
//	void mapSave();
//
//	void mapLoad();
//
//	void tilePrint();
//
//	void tileEraser();
//
//	tileMap();
//	~tileMap();
//};
//
