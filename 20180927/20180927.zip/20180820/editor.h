#pragma once
#include "scene.h"

class button;

#define TILE_SIZEX 40
#define TILE_SIZEY 40

#define SAMPLE_COUNTX 5
#define SAMPLE_COUNTY 9

#define TILE_MAXCOUNTX 60
#define TILE_MAXCOUNTY 60

enum tagMOUSE_STATE
{
	MOUSE_IDLE1,
	MOUSE_UP1,
	MOUSE_DOWN1,
	MOUSE_NUM1
};

enum tagSELECTED_OBJ {
	isTerrain, isUnit
};

enum tagSELECTED_TILE {
	tileset1, tileset2, tileset3, tileset4
};

enum tagSELECTED_SIZE {
	x800 = 800, x1600 = 1600, x2000 = 2000, x2400 = 2400
};

class editor : public scene
{
private:
	bool m_bIsSelectSize; // �޴�â���� ���ð���
		
	
	tagTile * m_pTiles[MAX_TILECOUNTX * MAX_TILECOUNTY];  // �׷��� Ÿ���� ���� // ������ ������ �Ǵ� Ÿ���� ����
	tagSampleTile m_pSampleTiles[SAMPLE_COUNTX * SAMPLE_COUNTY]; // �������� Ÿ��������
	RECT m_rcSelectedTile;
	tagSELECTED_TILE st_selTile;
	tagSELECTED_SIZE st_selSize;
	tagMOUSE_STATE st_mouse;
	tagSELECTED_OBJ st_obj;

	image* m_pTileSet[4]; // �� 4��
	image* m_pBox;

	button * m_pBtnLspace;
	button * m_pBtnRspace;

public:
	static int m_nPreviewNum;

	friend void SpaceFunc_left(void);
	friend void SpaceFunc_right(void);

	void ButtonEvent(HWND hWnd, UINT iMessage, WPARAM wParam);
	void SaveEvent();
	void LoadEvent();


	HRESULT init();


	void release();


	void update();
	void SizeUpdate();

	void render(HDC hdc);



	editor();
	~editor();
};

