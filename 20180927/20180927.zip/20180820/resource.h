//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 20180820.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDC_MYICON                      2
#define IDD_MY20180814_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_MY20180814                  107
#define IDI_SMALL                       108
#define IDC_MY20180814                  109
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDR_MENU2                       130
#define ID_32771                        32771
#define ID_NOTICE_HELP                  32772
#define ID_OBJECT_TERRAINS              32773
#define ID_OBJECT_OBJECTS               32774
#define ID_FILE_SAVE                    32775
#define ID_FILE_LOAD                    32776
#define ID_FILE_SAVDANDSTART            32777
#define ID_FILE_EXIT                    32778
#define ID_OBJECT_TERRAINS32779         32779
#define ID_FILE_SAVE32780               32780
#define ID_FILE_SAVEANDSTART            32781
#define ID_OBJECT_UNITS                 32782
#define ID_MAPSIZE_X800                 32783
#define ID_MAPSIZE_X1600                32784
#define ID_MAPSIZE_X2000                32785
#define ID_MAPSIZE_X2400                32786
#define ID_SIZE_X                       32787
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
