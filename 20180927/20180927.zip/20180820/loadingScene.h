#pragma once
#include "scene.h"

class loadingScene : public scene
{
public:
	loadingScene();
	~loadingScene();
};

